# Assistente de IA com Google Gemini

Projeto baseado no site original, com a conexão Claude substituída pela API oficial do Google Gemini. A chave da API fica no servidor e não é enviada ao navegador.

## Recursos preservados

- Chat com histórico salvo localmente no aparelho
- Modos Geral, Professor, Revisor e Analista
- Modo Jogo 3D
- Modo Gemini Code
- Raciocínio profundo
- Anexar até 4 imagens
- Robô Bit e opção de voz
- Painel Programar IA
- Personalização das instruções e escolha do modelo
- Monitoramento Global 24h: notícias GDELT, terremotos USGS, eventos NASA, clima de Recife, cotações e curiosidade da Wikipédia, com boletim resumido pelo Gemini
- Super API Unificada: perguntas ao GitHub Models (`openai/gpt-4o-mini`) e consulta de perfil e cinco repositórios populares de qualquer usuário público do GitHub
- Backup e download do HTML modificado
- Acesso ao chat protegido por uma senha privada (`APP_PASSWORD`)

## Monitoramento Global 24h

O botão **Monitoramento 24h** no cabeçalho consulta as fontes públicas no servidor e pede ao Gemini 2.5 Flash um boletim executivo. O painel também permite expandir os dados brutos. A rota `GET /api/panorama` exige o mesmo cabeçalho `X-App-Password` usado pelo chat. As rotas `POST /api/ai/chat` e `GET /api/github/usuario/:username` também exigem essa senha. O recurso foi integrado ao servidor Node.js existente, portanto não é necessário instalar ou executar FastAPI/Python. Se uma fonte externa falhar, as demais continuam sendo consultadas e a falha aparece nos dados.

## Antes de publicar

Você precisa de duas coisas suas: uma chave Gemini e uma senha privada para o site. Não envie essas informações no chat nem coloque a chave dentro do HTML.

1. Crie sua chave em https://aistudio.google.com/app/apikey.
2. No serviço de hospedagem, configure as variáveis de ambiente:
   - `GEMINI_API_KEY`: sua chave do Google AI Studio.
   - `GITHUB_TOKEN`: token pessoal do GitHub com acesso ao GitHub Models (permissão de leitura de modelos); usado também para ampliar o limite das consultas públicas ao GitHub.
   - `APP_PASSWORD`: uma senha forte que só você conheça.
3. Não publique o arquivo `.env`. Ele está no `.gitignore`.

## Publicar pelo Render

O arquivo `render.yaml` já contém a configuração básica do serviço.

1. Extraia o ZIP no computador.
2. Envie a pasta `assistente-gemini` para um repositório privado no GitHub.
3. Entre em https://render.com e crie uma conta ou entre na sua.
4. Escolha **New +** e depois **Blueprint**.
5. Conecte o repositório privado que contém o `render.yaml`.
6. Quando o Render pedir as variáveis, informe `GEMINI_API_KEY` e `APP_PASSWORD`.
7. Aguarde o deploy e abra o endereço `.onrender.com` criado para o serviço.
8. Na primeira mensagem enviada ao assistente, digite a senha `APP_PASSWORD` que você configurou. Ela fica guardada apenas na sessão atual do navegador.

A hospedagem gratuita pode deixar o serviço inativo quando não está sendo usado; a primeira abertura depois de um período parado pode demorar.

## Rodar no computador

É necessário Node.js 20 ou superior.

```bash
npm install
```

Copie `.env.example` para `.env` e preencha os valores:

```env
GEMINI_API_KEY=sua_chave_do_google
GITHUB_TOKEN=seu_token_do_github
APP_PASSWORD=uma_senha_forte_so_sua
PORT=3000
```

Depois execute:

```bash
npm start
```

Abra http://localhost:3000.

## Notas importantes

- O navegador não recebe a chave Gemini. Todas as chamadas passam pelo servidor.
- O chat exige a senha privada definida em `APP_PASSWORD`.
- O histórico do chat fica no armazenamento local do navegador, não em uma conta online.
- O botão de alterar o site gera um HTML para baixar. Um site aberto no navegador não pode substituir sozinho os arquivos na hospedagem; para publicar a alteração, envie o HTML baixado para a hospedagem.
- O uso da API Gemini está sujeito aos limites, à disponibilidade dos modelos e às condições de cobrança do Google.


## Super API Unificada

Configure `GITHUB_TOKEN` nas variáveis de ambiente da hospedagem. Crie um token do GitHub com a permissão necessária para usar GitHub Models (Models: read, quando disponível para o tipo de token escolhido). Não coloque o token no HTML nem envie pelo navegador. O painel **Super API** disponibiliza:

- `POST /api/ai/chat` com JSON `{ "prompt": "sua pergunta" }`, autenticado por `X-App-Password`; usa `openai/gpt-4o-mini` no endpoint oficial GitHub Models.
- `GET /api/github/usuario/:username`, autenticado por `X-App-Password`; retorna dados públicos do perfil e até cinco repositórios ordenados por estrelas. A consulta de perfil também funciona sem `GITHUB_TOKEN`, mas fica sujeita ao limite público do GitHub.

O token é opcional para o restante do site. Sem ele, o chat Gemini e o Monitoramento Global continuam disponíveis, mas a IA do GitHub Models fica desativada.


## Super IA 2.0: agentes, Skills e memória

A versão 2.0 acrescenta uma central de agentes especializados (Programador, Pesquisador, Segurança, Analista, Professor e Monitor de APIs), três Skills iniciais (Revisão de código, Integração de APIs e Planejamento técnico) e memória editável no servidor. A central fica no botão **Agentes + Memória**.

### Rotas novas

- `GET /api/agents`: lista agentes e Skills disponíveis.
- `POST /api/agents/run`: executa uma tarefa com agente e Skill opcionais.
- `GET /api/memory`: lista as memórias guardadas.
- `POST /api/memory`: guarda `{ "text": "...", "tags": [] }`.
- `DELETE /api/memory/:id`: remove uma memória.

Todas exigem `X-App-Password`. As memórias são limitadas a 200 itens e 2.000 caracteres por item. O arquivo é gravado em `data/memory.json` por padrão; para mudar o local, configure `MEMORY_FILE`.

**Persistência na hospedagem:** o sistema de arquivos de hospedagens pode ser temporário. Para manter as memórias após reinicializações e novos deploys, configure um disco persistente no provedor (por exemplo, montado em `/var/data`) e defina `MEMORY_FILE=/var/data/memory.json`. Sem disco persistente, use a memória como recurso temporário ou conecte um banco de dados persistente.

Os agentes não executam comandos arbitrários nem alteram arquivos do servidor: eles geram respostas usando o Gemini. A execução de código e a edição automática do projeto continuam separadas e devem passar por revisão e testes.
